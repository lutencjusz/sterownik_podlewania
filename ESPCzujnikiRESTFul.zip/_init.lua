pcall(function()node.flashindex("httpServer")()end)
print ("Wczytano modul httpServer")

pcall(function()node.flashindex("kalendarz")()end)
print ("Wczytano modul kalendarz")

pcall(function()node.flashindex("logika")()end)
print ("Wczytano modul Logika")

pcall(function()node.flashindex("wyslijMail")()end)
print ("Wczytano modul wyslijMail")

pcall(function()node.flashindex("InfluxDB")()end)
print ("Wczytano modul InfluxDB")

pcall(function()node.flashindex("ServerWWW")()end)
print ("Wczytano modul ServerWWW")

